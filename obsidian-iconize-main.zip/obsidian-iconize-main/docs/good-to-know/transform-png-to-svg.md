# Transform PNG to SVG

At the moment, it is necessary to only use SVG files in Iconize. That means,
that this plugin currently does not support other files than SVG.

To transform and convert a PNG to a SVG, you could use
[Adobe](https://www.adobe.com/express/feature/image/convert/png-to-svg) which is
free of charge.

# Icon before file or folder name

It is pretty easy to set a icon before a file or folder name.

You simply need to `Right Click a file or folder > Change Icon` and then select
the icon you would like to set for this specific file or folder.
Be aware that this has the highest priority and overrides every other set icon
for this file or folder.

